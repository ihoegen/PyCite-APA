Welcome to PyCite, Created by Ian Hoegen, Hoegen Developments.
To use PyCite, simply click  the PyCite APA Free.exe file, and be sure to create a shortcut.
For more info, go to http://www.hoegendevelopments.ga